#include <iostream>
#include <vector>
#include <string>
#include <math.h>
using namespace std;


int str2num(string);
string numb2str(int);
string bitShortManage(int);
int bin2dec(int);
int dec2bin(int);
int reverseInt(int);

int reverseInt(int num)
{
    int new_num = 0;
    while(num > 0)
    {
            new_num = new_num*10 + (num % 10);
            num = num/10;
    }
    return new_num;
}



string numb2str(int num)
{
    int temp;
    num=reverseInt(num);
    string str="";
    while(num!=0)
    {
        temp=num%10;
        num/=10;
        char c=temp+'0';
        str=str+c;
    }
    return str;

}

int str2num(string s)
{
    int k=0;
    for(int i=0;i<s.length();i++)
    {
        char a=s[i];
        int n=a-'0';
        k=k*10+n;
    }
    return k;
}

string bitShortManage(int sbin)
{
    int temp;
    string fullBin;
    temp=sbin;
    int counter=0;
    while(temp!=0)
    {

        temp/=10;
        counter++;
    }
    if(counter==8)
    {
        return numb2str(sbin);
    }else
    {
        for(int i=counter; i<8;i++)
        {
            fullBin=fullBin+'0';
        }
        fullBin.append(numb2str(sbin));
        return fullBin;

    }



}

int bin2dec(int n)
{
    int decimal=0, i=0, rem;
    while (n!=0)
    {
        rem = n%10;
        n/=10;
        decimal += rem*pow(2,i);
        ++i;
    }
    return decimal;
}

int dec2bin(int n)  /* Function to convert decimal to binary.*/
{
    int rem, i=1, binary=0;
    while (n!=0)
    {
        rem=n%2;
        n/=2;
        binary+=rem*i;
        i*=10;
    }
    return binary;
}

int main (void)
{
    //cout<<bin2dec(10);
    unsigned char c;
    c=127;
    cout<<bitShortManage(111111);
    return 0;

}
