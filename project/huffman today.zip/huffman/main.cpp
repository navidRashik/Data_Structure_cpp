#include "huffman.h"


int main()
{

     Huffman t;
     t.file(); //count word
     t.getHuffmanCode(); //most of huffman code
//     t.fileRead();
     t.filewritebin(); //
     cout<<"---------------------------------------------------------------------------";
     cout<<"-----------------------compressed------------------";

 return 0;
}


