#include <iostream>
#include "UnsortedType.h"
#include "ItemType.h"
using namespace std;

int main()
{

    UnsortedType uns;
    cout<<uns.GetLength()<<endl;

    ItemType it[5];
    it[0].Initilize(5);
    it[1].Initilize(7);
    it[2].Initilize(6);
    it[3].Initilize(9);
    //


    for(int k=0; k<MAX_ITEMS-1;k++){
        uns.PutItem(it[k]);
        it[k].Print();
    }

    cout<<endl;

    it[4].Initilize(1);

    for(int l=0; l<MAX_ITEMS;l++){
        uns.PutItem(it[l]);
        it[l].Print();

    }
    cout<<endl;




    //GetItem part

    cout<<"its magic"<<endl;

    ItemType A[4];
    A[0].Initilize(4);
    bool f;


    //uns.GetItem(A[0],f);

    A[1].Initilize(5);
    A[2].Initilize(9);
    A[3].Initilize(10);


    //for loop dilei prob kore
    for(int n=0;n<4;n++)
        {

            //bool f=true;
            uns.GetItem(A[n],f);

            switch (f)
            {
            case false:
                cout<< "Item not found"<<endl;
                break;
            case true:
                cout<< "Item is found"<<endl;
                break;
            }
        }









    return 0;
}
